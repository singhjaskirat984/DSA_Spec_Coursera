import java.util.*

fun getEditDistance(s: String, t: String): Int {
    //write your code here
    return 0
}

fun main(args: Array<String>) {
    val scan = Scanner(System.`in`)

    val s = scan.next()
    val t = scan.next()

    println(getEditDistance(s, t))
}